#include <iostream>
#include "Special.h"

Special::Special(int id)
{
    interest =12;
    accountType =3;
    ID=id;
}



void Special::setFirstAmount(float money)
{
    first_amount=money;
}

void Special::withdraw(float money)
{
    if(amount-money<first_amount)
    {
        cout<<"Bu Hesabi Kullanabilmek Icin Hesabinizda En Az Ilk Yatirdiginiz Kadar Bakiye Olmalidir. "<<money<<" TL Cekemezsiniz!"<<endl;
    }
    else if(amount<money)
    {
        cout<<"Hesabinizda "<<amount<<" TL Bulunmaktadir.En Fazla "<<amount<<" TL Cekebilirsiniz!"<<endl;
    }
    else
    {
        amount -= money;
        cout<<money<<"TL Hesabinizdan Cekildi!"<<endl;
    }
}
