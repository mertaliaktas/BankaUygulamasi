#ifndef SPECIAL_H_INCLUDED
#define SPECIAL_H_INCLUDED

#include "Account.h"

using namespace std;

class Special:public Account
{
public:
    Special(int);
    virtual void withdraw(float money);
    void setFirstAmount(float);
};

#endif // SPECIAL_H_INCLUDED
