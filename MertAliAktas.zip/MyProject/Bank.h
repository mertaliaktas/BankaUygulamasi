#ifndef BANK_H_INCLUDED
#define BANK_H_INCLUDED

#include "Account.h"
#include "ShortTerm.h"
#include <iostream>
class Bank
{
private:
    int sizeAccountt=0;

public:
    void getAccount();
    time_t getDate();
    void deposit(int ID,float cash);
    void setDate();
    Bank();
    Account *accounts[100];
};

#endif // BANK_H_INCLUDED
