#include "Bank.h"
#include "ShortTerm.h"
#include "LongTerm.h"
#include "Current.h"
#include "Special.h"
#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include "Account.h"

using namespace std;

Bank::Bank()
{
    // Tum Listeyi Gezerek NULL 'a Esitliyor.
    for(int i=0; i<100; i++)
    {
        accounts[i]=NULL;
    }
    // Sistemin Baslangic Tarihini Ayarliyor.
    time_t start = time(NULL);
    tm *start_up = localtime(&start);
    start_up->tm_mday=1;
    start_up->tm_mon =0;
    start_up->tm_year =117;

    int ch;
    cout<<"\n"<<setw(30)<<"! Hosgeldiniz !\n"<<endl;
    cout<<setw(23)<<"Tarih --> "<<start_up->tm_mday<<"/"<<start_up->tm_mon+1<<"/"<<start_up->tm_year+1900<<endl;


    do
    {
        cout<<"-------------------------------------------------\n";
        cout<<setw(35)<<"Ne Yapmak Isterdiniz?"<<endl;
        cout<<"-------------------------------------------------\n";
        cout<<"| Kisa Vadeli Hesap Olusturmak Icin  | 1 (Bir)   |\n"
            <<"| Uzun Vadeli Hesap Olusturmak Icin  | 2 (Iki)   |\n"
            <<"| Ozel Hesap Olusturmak Icin         | 3 (Uc)    |\n"
            <<"| Cari Hesap Olusturmak Icin         | 4 (Dort)  |\n"
            <<"| Hesaba Para Yatirmak Icin          | 5 (Bes)   |\n"
            <<"| Hesaptan Para Cekmek Icin          | 6 (Alti)  |\n"
            <<"| Sistem Tarihini Duzenlemek Icin    | 7 (Yedi)  |\n"
            <<"| Hesaplari Goruntulemek Icin        | 8 (Sekiz) |\n"
            <<"| ID Numaralarini Listelemek Icin    | 9 (Dokuz) |\n"
            <<"| Cekilis Yapmak Icin                | 10 (On)   |\n"
            <<"| Cikmak icin                        | 0 (Sifir) |\n"
            <<"--------------------------------------------------\n|->Seciminiz: ";
        cin>>ch;
        switch(ch)
        {
        // ID ile birlikte Istenilen Siniftan Nesne Olusturuyor. Ilk Bakiyeyi Ayarliyor ve Listeye Ekliyor.
        case 1:
        {
            cout<<"Kisa Vadeli Hesap Size Yillik %17 Faiz Imkani Sunar.Bu Hesabi Kullanabilmek Icin Hesabinizda En Az 1000 TL Olmalidir.\n";
            ShortTerm *st = new ShortTerm(16253+sizeAccountt);
            int x;
            cout<<"Ne Kadar Para Yatirmak Istersiniz?(TL)"<<endl;
            cin>>x;
            if(x<1000)
            {
                cout<<"Bu Hesabi Kullanabilmek Icin Hesabiniza En Az 1000 TL Yatirmaniz Gerekmektedir! "<<endl;
                break;
            }
            else
            {
                st->deposit(x);
                cout<<"Hesabiniz Basariyla Olusturuldu! ID Numaraniz : "<<st->getID()<<endl;
                accounts[sizeAccountt++]=st;
                break;
            }

        }
        case 2:
        {
            cout<<"Uzun Vadeli Hesap Size Yillik %24 Faiz Imkani Sunar.Bu Hesabi Kullanabilmek Icin Hesabinizda En Az 1500 TL Olmalidir.\n";
            LongTerm *lt= new LongTerm(16253+sizeAccountt);
            int x;
            cout<<"Ne Kadar Para Yatirmak Istersiniz?(TL)"<<endl;
            cin>>x;
            if(x<1500)
            {
                cout<<"Bu Hesabi Kullanabilmek Icin Hesabiniza En Az 1500 TL Yatirmaniz Gerekmektedir! "<<endl;
                break;
            }
            else
            {
                lt->deposit(x);
                cout<<"Hesabiniz Basariyla Olusturuldu! ID Numaraniz : "<<lt->getID()<<endl;
                accounts[sizeAccountt++]=lt;
                break;
            }

        }

        case 3:
        {
            cout<<"Ozel Hesap Size Yillik %12 Faiz Imkani Sunar.Bu Hesabi Kullanabilmek Icin Hesabinizi Acarken Yatirilan Para Hesabinizda Daima Mevcut Olmalidir.\n";
            Special *sp= new Special(16253+sizeAccountt);
            int x;
            cout<<"Ne Kadar Para Yatirmak Istersiniz?(TL)"<<endl;
            cin>>x;
            sp->deposit(x);
            cout<<"Hesabiniz Basariyla Olusturuldu! ID Numaraniz : "<<sp->getID()<<endl;
            sp->setFirstAmount(x);
            accounts[sizeAccountt++]=sp;
            break;
        }
        case 4:
        {
            cout<<"Cari Hesap Faizsiz Bir Hesaptir.Hicbir Sart Olmadan Dilediginizce Islem Yapabilirsiniz.\n";
            Current *c= new Current(16253+sizeAccountt);
            int x;
            cout<<"Ne Kadar Para Yatirmak Istersiniz?(TL)"<<endl;
            cin>>x;
            c->deposit(x);
            cout<<"Hesabiniz Basariyla Olusturuldu! ID Numaraniz : "<<c->getID()<<endl;
            accounts[sizeAccountt++]=c;
            break;
        }
        // ID ye gore O Hesaba Para Yatiriyor.
        case 5:
        {
            int y,z;
            bool v=false;
            cout<<"Kac Numarali ID'ye Ne Kadar Para Yatirmak Istiyorsunuz? (Aralarinda Bosluk Kullanarak Tuslayiniz)\n";
            cin>>y;
            cin>>z;
            for(int i =0; i<sizeAccountt; i++)
            {
                if(accounts[i]->getID()==y)
                {
                    accounts[i]->deposit(z);
                    v = true;
                    break;
                }
            }
            if(v== false)
                cout<<"Bu ID'ye Ait Hesap Bulunamadi!"<<endl;
            break;

        }
        // ID ye gore O Hesaptan Para Cekiyor.
        case 6:
        {
            int y,z;
            bool v=false;
            cout<<"Kac Numarali ID'den Ne Kadar Para Cekmek Istiyorsunuz? (Aralarinda Bosluk Kullanarak Tuslayiniz)\n";
            cin>>y;
            cin>>z;
            for(int i =0; i<sizeAccountt; i++)
            {
                if(accounts[i]->getID()==y)
                {
                    if(accounts[i]->getAccountType()==1)
                    {
                        ((ShortTerm*)accounts[i])->withdraw(z);
                        v=true;
                        break;
                    }

                    else if(accounts[i]->getAccountType()==2)
                    {
                        ((LongTerm*)accounts[i])->withdraw(z);
                        v=true;
                        break;
                    }

                    else if(accounts[i]->getAccountType()==3)
                    {
                        ((Special*)accounts[i])->withdraw(z);
                        v=true;
                        break;
                    }

                    else if(accounts[i]->getAccountType()==4)
                    {
                        ((Current*)accounts[i])->withdraw(z);
                        v=true;
                        break;
                    }

                }

            }
            if(v== false)
                cout<<"Bu ID'ye Ait Hesap Bulunamadi!"<<endl;
            break;
        }
        // Sistemin Tarihini Ayarlayip Hesaplara Faiz Uyguluyor.
        case 7:
        {
            setDate();
            for(int i=0; i<sizeAccountt; i++)
            {
                accounts[i]->Benefit();
            }
            break;
        }
        // Hesaplari ID ve Bakiye Olarak Goruntuluyor.
        case 8:
        {
            if(accounts[0]!=NULL)
            {
                for(int i= 0; i<sizeAccountt; i++)
                {
                    if(accounts[i]!=0)
                        cout<<"ID: "<<accounts[i]->getID()<<" |"<<"Bakiye: "<<accounts[i]->getBalance()<<" TL"<<endl;
                }
                break;
            }
            else
                cout<<"Sistemde Hesap Bulunmamaktadir!"<<endl;

            break;
        }
        // Sistemdeki Hesaplarin ID Numaralarini Goruntuluyor.
        case 9:
        {
            if(accounts[0]->getID()!=0)
            {
                for(int i= 0; i<sizeAccountt; i++)
                {
                    if(accounts[i]->getID()!=0)
                        cout<<accounts[i]->getID()<<" |"<<endl;
                }
                break;
            }
            else
                cout<<"Sistemde Hesap Bulunmamaktadir!"<<endl;

            break;
        }
        // Ozel Hesaplar Arasinda Cekilis Yapiyor.
        case 10:
        {

            bool isFound= false;
            int ctrlRate=0;

            if(sizeAccountt==0)
            {
                cout<<"Sistemde Hesap Bulunmamaktadir!"<<endl;
                break;
            }
            for(int i =0; i<sizeAccountt; i++)
            {
                if(accounts[i]->getAccountType()==3)
                {
                    ctrlRate+= accounts[i]->getBalance()/2000;
                    isFound = true;
                }
            }
            if(isFound==false || ctrlRate == 0)
            {
                cout<<"Sistemde Ozel Hesap Bulumamaktadir! Veya Cekilis Haklari Yoktur!"<<endl;
                break;
            }
            int rate;
            bool isWin= false;
            int winnerNumber = rand()%100+1;
            while(isWin==false)
            {
                for(int i=0; i<sizeAccountt; i++)
                {
                    if(accounts[i]!=NULL && accounts[i]->getAccountType()==3 && isWin==false)
                    {
                        rate = accounts[i]->getBalance()/2000;

                        for(int j=0; j<rate; j++)
                        {
                            int randomNumber = rand()%100+1;
                            if(randomNumber==winnerNumber && isWin == false)
                            {
                                cout<<"Cekilisi ID : "<<accounts[i]->getID()<<" Kazandi!"<<endl;
                                accounts[i]->deposit(10000);
                                cout<<"Yeni Bakiye : "<<accounts[i]->getBalance()<<" TL"<<endl;
                                isWin=true;
                            }
                        }


                    }
                }
            }


            break;
        }

        case 0:
        {
            cout<<"Bankamizdan Cikiyorsunuz.\nYine Bekleriz...\n\n"<<endl;
            break;
        }

        default:
        {
            cout<<"Yanlis Veya Eksik Tuslama Yaptiniz.Lutfen Tekrar Tuslar Misiniz ?\n";
            break;
        }

        }
    }
    while(ch!=0);
}
void Bank::getAccount()
{
    for(int i=0; i<sizeAccountt; i++)
    {
        if(accounts[i]->getID()!=0)
            cout<<accounts[i]->getID()<<" |"<<endl;
    }
}



void Bank::setDate()
{
    int x,y,z;
    cout<<"Sistemin Tarihini Aralarinda Bosluk Kullanarak Tuslayiniz(Gun Ay Yil)"<<endl;
    cin>>x>>y>>z;
    if(1<=x<=31 && 1<= y <= 12 && z-2017>=0 )
    {
        time_t start = time(NULL);
        tm *start_up = localtime(&start);
        start_up->tm_mday=x;
        start_up->tm_mon =y-1;
        start_up->tm_year =z-1900;
        cout<<setw(23)<<"Tarih --> "<<start_up->tm_mday<<"/"<<start_up->tm_mon+1<<"/"<<start_up->tm_year+1900<<endl;
    }
    else
        cout<<"Tarih Formati Yanlis! Gun 1-31 , Ay 1-12 , Yil 2017' Den Buyuk Olmalidir! "<<endl;

}


