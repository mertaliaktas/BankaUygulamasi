#ifndef SHORTTERM_H_INCLUDED
#define SHORTTERM_H_INCLUDED
#include "Account.h"

class ShortTerm:public Account
{
public:
    virtual void withdraw(float money);
    ShortTerm(int);
};

#endif // SHORTTERM_H_INCLUDED
