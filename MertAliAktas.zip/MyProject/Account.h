#ifndef ACCOUNT_H_INCLUDED
#define ACCOUNT_H_INCLUDED
#include <ctime>
class Account
{
public:
    void deposit(float money);
    virtual void withdraw(float money)=0;
    float getBalance();
    int getID();
    void setID();
    void Benefit();
    int getInterest();
    time_t getDate();
    int getAccountLenght();
    time_t getStartingDate();
    int getAccountType();
    Account();

protected:
    float amount;
    int ID;
    int accountType;
    float interest;
    float first_amount;
    int chance;
};






#endif // ACCOUNT_H_INCLUDED
