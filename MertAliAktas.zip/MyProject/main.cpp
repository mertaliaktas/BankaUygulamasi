#include <iostream>
#include <windows.h>
#include "Bank.h"

using namespace std;

int main()
{
    system("title Bank Application");
    system("color A");
    Bank x;

}
