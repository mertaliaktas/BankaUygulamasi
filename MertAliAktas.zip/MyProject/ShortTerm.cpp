#include <iostream>
#include "ShortTerm.h"


using namespace std;

ShortTerm::ShortTerm(int id)
{
    interest =17;
    accountType=1;
    ID=id;
}


void ShortTerm::withdraw(float money)
{
    if(getBalance()-money>=1000)
    {
        if(amount<money)
        {
            cout<<"Hesabinizda "<<amount<<" TL Bulunmaktadir.En Fazla "<<amount<<" TL Cekebilirsiniz!"<<endl;
        }
        else
        {
            amount -= money;
            cout<<money<<"TL Hesabinizdan Cekildi!"<<endl;
        }
    }
    else
        cout<<"Uzun Vadeli Hesapta En Az 1000 TL Olmalidir! "<<money<<" TL Cekemezsiniz!"<<endl;

}
