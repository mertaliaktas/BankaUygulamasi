#include <iostream>
#include "LongTerm.h"


using namespace std;


LongTerm::LongTerm(int id)
{
    interest =24;
    accountType = 2;
    ID=id;
}



void LongTerm::withdraw(float money)
{
    if(getBalance()-money>=1500)
    {
        if(amount<money)
        {
            cout<<"Hesabinizda "<<amount<<" TL Bulunmaktadir.En Fazla "<<amount<<" TL Cekebilirsiniz!"<<endl;
        }
        else
        {
            amount -= money;
            cout<<money<<"TL Hesabinizdan Cekildi!"<<endl;
        }
    }
    else
        cout<<"Uzun Vadeli Hesapta En Az 1500 TL Olmalidir! "<<money<<" TL Cekemezsiniz!"<<endl;

}



