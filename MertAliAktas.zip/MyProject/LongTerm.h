#ifndef LONGTERM_H_INCLUDED
#define LONGTERM_H_INCLUDED

#include "Account.h"

class LongTerm:public Account
{
public:
    virtual void withdraw(float money);
    LongTerm(int);
};

#endif // LONGTERM_H_INCLUDED
