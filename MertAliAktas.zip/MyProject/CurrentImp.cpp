#include <iostream>
#include "Current.h"

using namespace std;

Current::Current(int id)
{
    accountType =4;
    ID=id;
}

void Current::withdraw(float money)
{
    if(amount<money)
    {
        cout<<"Hesabinizda "<<amount<<" TL Bulunmaktadir.En Fazla "<<amount<<" TL Cekebilirsiniz!"<<endl;
    }
    else
    {
        amount -= money;
        cout<<money<<"TL Hesabinizdan Cekildi!"<<endl;
    }
}
