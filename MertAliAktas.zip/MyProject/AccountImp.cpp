#include "Account.h"
#include "Bank.h"
#include <iostream>
#include <ctime>
#include "Account.h"

using namespace std;

Account::Account()
{
    // Constructor'da ilk degerleri ayarliyor.
    amount=0.0;
    ID=0;
    accountType=0;
    first_amount=0;
    interest=0;
}

void Account::deposit(float money)
{
    // Parametre olarak aldigi miktari bakiyeye ekliyor.
    amount+=money;
    cout<<money<<" TL Hesabiniza Yatirildi!"<<endl;
}


float Account::getBalance()
{
    // Bakiyeyi donduruyor.
    return amount;
}

int Account::getID()
{
    // ID yi donduruyor.
    return ID;
}




time_t Account::getStartingDate()
{
    // Baslangic tarihini ayarliyor.
    time_t now = time(NULL);
    tm* startingDate = localtime(&now);
    startingDate->tm_mday=1;
    startingDate->tm_mon=0;
    startingDate->tm_year=117;
    return mktime(startingDate);
}

time_t Account::getDate()
{
    // Suanki Tarihi Donduruyor.
    time_t now = time(NULL);
    return now;
}

int Account::getAccountType()
{
    // Hesap Turunu Donduruyor.
    return accountType;
}


void Account::Benefit()
{
    // Suanki Tarihle Baslangic
    float day=difftime(getDate(),getStartingDate())/(60*60*24);
    float gain = amount*(day/365) *(interest/100);
    amount+=gain;
    cout<<"ID: "<<ID<<" Hesabina "<<day<<" Gun icin "<<gain<<" TL Faiz uygulanmistir.\nYeni Bakiye : "<<amount<<" TL"<<endl;

}


void Account::setID()
{
    // ID 'yi NULL 'a esitliyor.
    ID = NULL;
}

